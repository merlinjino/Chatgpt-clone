import 'dart:convert';
import 'package:http/http.dart' as http;

class ChatService {
  static Future<String> sendMessage(String message) async {
    final url = Uri.parse('http://10.0.2.2:8000/chat'); // Replace with your deployed URL
    final response = await http.post(
      url,
      headers: {"Content-Type": "application/json"},
      body: json.encode({"user_input": message}),
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      return data['reply'];
    } else {
      throw Exception('Failed to get response');
    }
  }
}
